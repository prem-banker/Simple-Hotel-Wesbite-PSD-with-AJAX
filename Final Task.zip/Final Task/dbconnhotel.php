<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotels";

$conn = new mysqli("localhost","root","","hotels");
?>